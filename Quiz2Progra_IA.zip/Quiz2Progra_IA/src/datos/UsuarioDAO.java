/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import entidades.Usuario;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private final String archivo = "usuarios.txt";

    public void agregar(Usuario u) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            bw.write(u.getId() + "|" + u.getNombre() + "|" + u.getCorreo());
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error al guardar usuario");
        }
    }

    public List<Usuario> listar() {

        List<Usuario> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split("\\|");

                Usuario u = new Usuario(
                        Integer.parseInt(datos[0]),
                        datos[1],
                        datos[2]
                );

                lista.add(u);
            }

        } catch (IOException e) {
            System.out.println("Error al leer archivo");
        }

        return lista;
    }

    public Usuario buscar(int id) {

        for (Usuario u : listar()) {
            if (u.getId() == id) {
                return u;
            }
        }
        return null;
    }

    public void eliminar(int id) {

        List<Usuario> lista = listar();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Usuario u : lista) {
                if (u.getId() != id) {
                    bw.write(u.getId() + "|" + u.getNombre() + "|" + u.getCorreo());
                    bw.newLine();
                }
            }

        } catch (IOException e) {
            System.out.println("Error al eliminar");
        }
    }

    public void modificar(Usuario nuevo) {

        List<Usuario> lista = listar();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Usuario u : lista) {

                if (u.getId() == nuevo.getId()) {
                    bw.write(nuevo.getId() + "|" + nuevo.getNombre() + "|" + nuevo.getCorreo());
                } else {
                    bw.write(u.getId() + "|" + u.getNombre() + "|" + u.getCorreo());
                }
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error al modificar");
        }
    }
}
