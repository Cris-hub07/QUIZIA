/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

import datos.UsuarioDAO;
import entidades.Usuario;
import java.util.List;

public class UsuarioServicio {

    private UsuarioDAO dao = new UsuarioDAO();

    public void agregarUsuario(Usuario u) {

        if (u.getNombre().isEmpty() || u.getCorreo().isEmpty()) {
            System.out.println("Campos vacíos");
            return;
        }

        if (dao.buscar(u.getId()) != null) {
            System.out.println("ID ya existe");
            return;
        }

        dao.agregar(u);
    }

    public List<Usuario> listarUsuarios() {
        return dao.listar();
    }

    public Usuario buscarUsuario(int id) {
        return dao.buscar(id);
    }

    public void eliminarUsuario(int id) {
        dao.eliminar(id);
    }

    public void modificarUsuario(Usuario u) {
        dao.modificar(u);
    }
}
