/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacion;

import entidades.Usuario;
import negocio.UsuarioServicio;
import java.util.Scanner;

public class Menu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UsuarioServicio servicio = new UsuarioServicio();

        int op;

        do {

            System.out.println("\n=== MENU ===");
            System.out.println("1. Agregar");
            System.out.println("2. Listar");
            System.out.println("3. Buscar");
            System.out.println("4. Modificar");
            System.out.println("5. Eliminar");
            System.out.println("6. Salir");

            op = sc.nextInt();

            switch (op) {

                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nombre: ");
                    String nom = sc.nextLine();

                    System.out.print("Correo: ");
                    String cor = sc.nextLine();

                    servicio.agregarUsuario(new Usuario(id, nom, cor));
                    break;

                case 2:
                    for (Usuario u : servicio.listarUsuarios()) {
                        System.out.println(u);
                    }
                    break;

                case 3:
                    System.out.print("ID buscar: ");
                    Usuario ub = servicio.buscarUsuario(sc.nextInt());
                    System.out.println(ub != null ? ub : "No existe");
                    break;

                case 4:
                    System.out.print("ID modificar: ");
                    int idm = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nuevo nombre: ");
                    String nm = sc.nextLine();

                    System.out.print("Nuevo correo: ");
                    String cm = sc.nextLine();

                    servicio.modificarUsuario(new Usuario(idm, nm, cm));
                    break;

                case 5:
                    System.out.print("ID eliminar: ");
                    servicio.eliminarUsuario(sc.nextInt());
                    break;
            }

        } while (op != 6);

    }
}
